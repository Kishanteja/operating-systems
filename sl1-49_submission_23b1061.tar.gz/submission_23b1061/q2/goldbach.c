#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>
#include <fcntl.h>

#define maxN 100000
int nthreads = 10; // no of threads
bool primes[maxN+1];
int gb_count[maxN+1];
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void* mythread(void *arg) {
  int start = *(int *)arg;
  // pthread_mutex_lock(&lock);
  int end = start + (maxN / nthreads) - 1;
  for(int n = start; n <= end; n+=2) {
    for(int p1 = 2; p1 <= n/2; p1++) {
      int p2 = n - p1;
      if(primes[p1] && primes[p2]) {
	gb_count[n]++;
      }
    }
  }
  // for last thread the maxn is going to missed as it is not in
  // for loop so i added that extra down
  if(start == ((nthreads - 1) * maxN) / nthreads) {
    for(int n = maxN; n <= maxN; n+=2) {
    for(int p1 = 2; p1 <= n/2; p1++) {
      int p2 = n - p1;
      if(primes[p1] && primes[p2]) {
	gb_count[n]++;
      }
    }
  }
  }
  // pthread_mutex_unlock(&lock);
}

void main(int argc, char *argv[]) {
  
  //Sieve of Eratosthenes
  for(int i =0; i <= maxN; i++) {
    primes[i] = true;
    gb_count[i] = 0;
  }
  
  primes[0] = primes[1] = false;

  for(int p = 2; p <= sqrt(maxN); p++) {
    if(primes[p]) {
      for(int i = p*p; i <= maxN; i += p)
	primes[i] = false;
    }
  }

  int prime_count = 0;
  for(int p = 2; p <= maxN; p++)
    if(primes[p]) {
      prime_count++;
      //printf("Found prime %d\n", p);
    }
  printf("Computed primes upto %d, count = %d\n", maxN, prime_count);

  
  //Compute number of Goldbach pairs

  //start timer
  struct timeval tv_start, tv_end;
  gettimeofday(&tv_start, 0);

  //THE CALCULATIONS BELOW TO BE DONE IN PARALLEL
  // for(int n = 4; n <= maxN; n+=2) {
  //   for(int p1 = 2; p1 <= n/2; p1++) {
  //     int p2 = n - p1;
  //     if(primes[p1] && primes[p2]) {
	// gb_count[n]++;
  //     }
  //   }
  // }
  pthread_t threads[nthreads];
  int starts[nthreads];
  for(int i = 0; i < nthreads; i++) {
    starts[i] = ((i) * maxN) / nthreads;
    pthread_create(&threads[i], NULL, mythread, &starts[i]);
  }
  for(int i = 0; i < nthreads; i++) {
    pthread_join(threads[i], NULL);
  }

  // THREADS TO JOIN HERE, DO NOT CHANGE CODE BELOW
  
  //end timer and calculate elapsed time
  gettimeofday(&tv_end, 0);
  unsigned long elapsed_usec = ((tv_end.tv_sec * 1000000) + tv_end.tv_usec) - ((tv_start.tv_sec * 1000000) + tv_start.tv_usec);
  printf("elapsed time: %lu microseconds\n", elapsed_usec);

  //print values to file for checking correctness
  FILE *fptr = fopen("output.txt", "w");
  for(int i = 4; i <= maxN; i+=2)
    fprintf(fptr, "%d %d\n", i, gb_count[i]);
  fclose(fptr);
}
