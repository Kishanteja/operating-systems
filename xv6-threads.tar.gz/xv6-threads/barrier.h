/*----------xv6 sync lab----------*/
int barrier_init(int);
int barrier_check(void);
/*----------xv6 sync lab end----------*/